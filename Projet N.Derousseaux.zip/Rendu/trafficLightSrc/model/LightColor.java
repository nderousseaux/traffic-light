package trafficlight.model;

public enum LightColor {
	GREEN,
	RED,
	ORANGE,

};

