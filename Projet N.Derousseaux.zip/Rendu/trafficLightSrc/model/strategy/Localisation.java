package trafficlight.model.strategy;

import trafficlight.model.TrafficLight;

public abstract class Localisation {


    //Constructeur
    public Localisation(){}

    //Méthodes d'instances
    public abstract void switchColor(TrafficLight t);

}
